﻿using System;

class Program
{
    static void Main()
    {
        
        Console.Write("Введите коэффициент a: ");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите коэффициент b: ");
        double b = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите коэффициент c: ");
        double c = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите количество итераций (точек): ");
        int iterations = Convert.ToInt32(Console.ReadLine());

        double[] roots = FindRoots(a, b, c);

        if (roots.Length == 0 || a > 0)
        {
            Console.WriteLine("Парабола не пересекает ось абсцисс или открыта вверх.");
            return;
        }

        double xMin = roots[0];
        double xMax = roots[1];

        double height = Polynomial(a, b, c, (xMin + xMax) / 2);

        Random random = new Random();
        int pointsUnderCurve = 0;

        for (int i = 0; i < iterations; i++)
        {
            double x = random.NextDouble() * (xMax - xMin) + xMin; 
            double y = random.NextDouble() * height; 
            if (y <= Polynomial(a, b, c, x))
            {
                pointsUnderCurve++;
            }
        }

        double rectangleArea = (xMax - xMin) * height;
        double areaUnderCurve = (double)pointsUnderCurve / iterations * rectangleArea;

        Console.WriteLine($"Площадь фигуры, ограниченной параболой и осью абсцисс: {areaUnderCurve}");
    }

    static double Polynomial(double a, double b, double c, double x)
    {
        return a * x * x + b * x + c;
    }

    static double[] FindRoots(double a, double b, double c)
    {
        double discriminant = b * b - 4 * a * c;

        if (discriminant > 0)
        {
            double root1 = (-b + Math.Sqrt(discriminant)) / (2 * a);
            double root2 = (-b - Math.Sqrt(discriminant)) / (2 * a);
            return new double[] { Math.Min(root1, root2), Math.Max(root1, root2) };
        }
        else if (discriminant == 0)
        {
            double root = -b / (2 * a);
            return new double[] { root, root };
        }
        else
        {
            return new double[0]; 
        }
    }
}

