﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите коэффициент a (x^3): ");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите коэффициент b (x^2): ");
        double b = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите коэффициент c (x): ");
        double c = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите коэффициент d (свободный член): ");
        double d = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите точность (например, 0.0001): ");
        double precision = Convert.ToDouble(Console.ReadLine());

        double x0 = 0; 

        double root = NewtonRaphson(a, b, c, d, x0, precision);
        Console.WriteLine($"Найденный корень: {root}");
    }

    static double NewtonRaphson(double a, double b, double c, double d, double initialGuess, double precision)
    {
        double x = initialGuess;
        double fValue = Polynomial(a, b, c, d, x);
        double fDerivativeValue = Derivative(a, b, c, x);

        while (Math.Abs(fValue) > precision)
        {
            x = x - fValue / fDerivativeValue; 
            fValue = Polynomial(a, b, c, d, x); 
            fDerivativeValue = Derivative(a, b, c, x); 
        }

        return x;
    }

    static double Polynomial(double a, double b, double c, double d, double x)
    {
        return a * Math.Pow(x, 3) + b * Math.Pow(x, 2) + c * x + d;
    }

    static double Derivative(double a, double b, double c, double x)
    {
        return 3 * a * Math.Pow(x, 2) + 2 * b * x + c;
    }
}
