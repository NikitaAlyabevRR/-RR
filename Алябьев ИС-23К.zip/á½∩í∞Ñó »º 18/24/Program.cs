﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите первое число (X): ");
        if (!int.TryParse(Console.ReadLine(), out int x) || x <= 0)
        {
            Console.WriteLine("Некорректный ввод. Пожалуйста, введите положительное целое число.");
            return;
        }

        Console.Write("Введите второе число (Y): ");
        if (!int.TryParse(Console.ReadLine(), out int y) || y <= 0)
        {
            Console.WriteLine("Некорректный ввод. Пожалуйста, введите положительное целое число.");
            return;
        }

        ulong result = Power(x, y);

        Console.WriteLine($"{x} в степени {y} равно {result}");
    }

    static ulong Power(int x, int y)
    {
        if (y == 0) return 1; 
        if (y == 1) return (ulong)x; 

        ulong half = Power(x, y / 2); 

        if (y % 2 == 0)
        {
            return Square(half); 
        }
        else
        {
            return (half * (ulong)x) + half * half;
        }
    }

    static ulong Square(ulong value)
    {
        ulong result = 0;

        for (ulong i = 0; i < value; i++)
        {
            result += value; 
        }

        return result;
    }
}
