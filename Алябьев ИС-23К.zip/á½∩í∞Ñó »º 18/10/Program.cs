﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите целое число (диаметр окружности): ");
        int diameter = Convert.ToInt32(Console.ReadLine());

        if (diameter < 1)
        {
            Console.WriteLine("Диаметр должен быть положительным целым числом.");
            return;
        }

        double radius = diameter / 2.0;

        DrawCircle(radius);
    }

    static void DrawCircle(double radius)
    {
        int diameter = (int)(radius * 2);
        char fillCharacter = '*';

        for (int i = 0; i <= diameter; i++)
        {
            for (int j = 0; j <= diameter; j++)
            {
                double distance = Math.Sqrt(Math.Pow(i - radius, 2) + Math.Pow(j - radius, 2));

                if (Math.Abs(distance - radius) < 0.5)
                {
                    Console.Write(fillCharacter);
                }
                else
                {
                    Console.Write(' ');
                }
            }
            Console.WriteLine(); 
        }
    }
}

