﻿using System;
namespace Programm_5
{
    class Program
    {
        static void Main()
        {
            double a = 6;
            double b = 10;
            double nA = -a;
            double nB = -b;
            double nAB = -a * -b;
            double otvet = nA - nB / (1 + nAB);
            Console.WriteLine($"Ответ {otvet}");
        }
    }
}