﻿using System;
namespace Proframm_4
{
    class Programm
    {
        static void Main()
        {
            int x = 4;
            double num_1, num_2, num_3, num_4;
            num_1 = Math.Pow(x, 2); num_1 = num_1 * 5;
            num_2 = 12 * x;
            num_3 = num_1 - num_2 + 4;
            num_4 = 6 - 15 * x;
            Console.WriteLine(num_3 / num_4);
        }
    }
}